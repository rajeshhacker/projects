-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2020 at 11:16 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountdetails`
--

CREATE TABLE `accountdetails` (
  `accountnumber` int(10) NOT NULL,
  `balance` int(10) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accountdetails`
--

INSERT INTO `accountdetails` (`accountnumber`, `balance`) VALUES
(1000000015, 2000),
(1000000016, 7500);

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(3) NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `email`, `status`) VALUES
(12, 'abc@gmail.com', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `accountnumber` int(10) NOT NULL,
  `path` varchar(50) NOT NULL DEFAULT 'profilepics',
  `medianame` varchar(30) NOT NULL DEFAULT 'default.jpeg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`accountnumber`, `path`, `medianame`) VALUES
(1000000015, 'profilepics', '1000000015.jpeg'),
(1000000016, 'profilepics', '1000000016.png');

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE `queries` (
  `id` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `queries`
--

INSERT INTO `queries` (`id`, `fullname`, `email`, `message`) VALUES
(1, 'Rajesh Kumar', 'rajpanwhar@gmail.com', 'Hi I am firing this query, this is for testing purpose');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `fullname`, `email`) VALUES
(1, 'Rajesh', 'rajpanwhar@gmail.com'),
(4, 'Muhammad Ibrahim', 'Ibrahim@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `fname` varchar(15) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `fathername` varchar(30) NOT NULL,
  `mothername` varchar(30) NOT NULL,
  `cnic` varchar(15) CHARACTER SET utf8 NOT NULL,
  `city` varchar(20) NOT NULL,
  `phonenumber` varchar(12) CHARACTER SET utf8 NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `province` varchar(15) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `accountnumber` int(10) NOT NULL,
  `pin` int(10) NOT NULL,
  `sec_question` varchar(50) NOT NULL,
  `sec_answer` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`fname`, `lname`, `fathername`, `mothername`, `cnic`, `city`, `phonenumber`, `dob`, `gender`, `province`, `designation`, `accountnumber`, `pin`, `sec_question`, `sec_answer`) VALUES
('Muhammad', 'Faizan', 'ABC', 'XYZ', '84878-7878785-4', 'Sukkur', '0384-5456454', '2009-02-10', 'male', 'sindh', 'customer', 1000000015, 12345678, 'what is your nick name?', 'kuku'),
('Muhammad', 'Ibrahim', 'AAAAA', 'BBBBB', '45565-6896565-6', 'Punjab', '0346-5454545', '2003-05-15', 'male', 'punjab', 'customer', 1000000016, 11223344, 'what is your favourite teacher name?', 'sir khalid');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountdetails`
--
ALTER TABLE `accountdetails`
  ADD PRIMARY KEY (`accountnumber`),
  ADD UNIQUE KEY `accountnumber` (`accountnumber`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`accountnumber`),
  ADD UNIQUE KEY `accountnumber` (`accountnumber`);

--
-- Indexes for table `queries`
--
ALTER TABLE `queries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`accountnumber`),
  ADD UNIQUE KEY `cnic` (`cnic`),
  ADD UNIQUE KEY `phonenumber` (`phonenumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `queries`
--
ALTER TABLE `queries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `accountnumber` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000000017;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accountdetails`
--
ALTER TABLE `accountdetails`
  ADD CONSTRAINT `accountdetails_ibfk_1` FOREIGN KEY (`accountnumber`) REFERENCES `users` (`accountnumber`) ON DELETE CASCADE;

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`accountnumber`) REFERENCES `users` (`accountnumber`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
